#!/bin/bash

echo 'Updating..'

sudo pacman -Syu --noconfirm
sudo pacman -Rs $(pacman -Qdtq) 

echo 'Updated and cleared orphaned packages successfully!'

sudo rm -rf ~/.cache/*

echo 'cleared cache!'

sudo rm -rf ~/yay

echo 'Rebooting pc..'

sleep 5
reboot

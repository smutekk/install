#!/bin/bash

# 1 = monitor
# 2 = res
# 3 = refreshrate

if [ -n "$1" ]; then
  cvtOutput=$(cvt12 $(echo "$2" | sed 's/x/ /') $2 -b)
  modeline=$(echo "$cvtOutput" | grep '^Modeline' | sed 's/^[^"]*\(".*\)/\1/')

  echo "$cvtOutput"
  echo "$modeline"

  read -p "Are you sure you want to continue? (This will overwrite your refresh rate!) " -n 1 -r
  echo

  if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "OwO.. prepare thyself.."

    xrandr --newmode $modeline
    xrandr --addmode $1 --mode $($modeline | sed 's/.*"\([^"]*\)".*/\1/')
    xrandr --output $1 --mode $($modeline | sed 's/.*"\([^"]*\)".*/\1/')
    
  fi
else
  echo '
  $1 is display (HDMI-A-1)
  $2 is resolution (1920x1080)
  $3 is targeted refresh rate (69)'
fi

#!/bin/bash
# 
#gl amy :pray:

weather=$(curl -s "wttr.in/toronto?format=3" | sed 's/^[^ ]* //')

echo $weather

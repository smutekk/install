#!/bin/bash



if [ "$1" == "-h" ]; then
    echo -e "-h help,\n-s set colour (setcol -s 0,0,0 0,0,0 .5)\n-o set opacity (setcol -o .5)\n-g returns set colour"
elif [ "$1" == "-o" ]; then
    echo "feature not yet implemented (too hard :c)"
elif [ "$1" == "-g" ]; then
    echo "Primary Colour = ($foregroundcolour)"
elif [ "$1" == "-s" ]; then

    #hyprland

    bgcolour=$(echo "rgba(0, 0, 0, 0.6)")
    accentcolour=$(echo "rgba($2,$4)")
    foregroundcolour=$(echo "rgba($3,$4)")

    

    line_number=16
    new_line="col.active_border = $accentcolour $foregroundcolour 65deg"
    selection_colour="$(pastel format hex $accentcolour)"
    formatted_colour="$(echo "$selection_colour" | sed 's/..$//')"
    
    sed -i "${line_number}s/.*/${new_line}/" /home/smutekk/.config/hypr/colours.conf
    sed -i "17s/.*/selection-color = ${selection_colour}/" /home/smutekk/.config/tofi/config
    sed -i "205s/.*/foreground = '${formatted_colour}'/" /home/smutekk/.config/cava/config

       
    cat > /home/smutekk/.config/waybar/style.css <<EOF
    * {
        font-family: monospace;
        font-size: 13px;
    }

    window#waybar {
        margin-top: 4px;
        background-color: rgba(0, 0, 0, 0);
        /* border-bottom: 2px solid rgba(69, 0, 255, 1); */
        color: #ffffff;
        padding: 20px;
    }
    
    button {
        /* Use box-shadow instead of border so the text isn't offset */
        box-shadow: inset 0 -3px transparent;
    }

    button:hover {
        background: inherit;
        box-shadow: inset 0 -2px #ffffff;
    }
    
    
    label:focus {
        background-color: rgba(30, 30, 30, 0.4);
    }
    
    label:hover {
        background: inherit;
        box-shadow: inset 0 -2px rgba(255,255,255, 0.4);
    }
    
    /* you can set a style on hover for any module like this */
    
    #workspaces button {
        padding: 0 5px;
        background-color: rgba(40,40,40,0);
        border: 1.6px inset transparent;
        border-radius: 5px;
        color: #ffffff;
    }
    
    #workspaces button:hover {
        background: rgba(0, 0, 0, 0.2);
    }
    
    #workspaces button.active {
        background-color: rgba(30,30,30,0.4);
        box-shadow: inset 0 -3px $accentcolour;
    }
    
    #workspaces button.focused {
        background-color: rgba(30,30,30,0.4);
        box-shadow: inset 0 -2px #ffffff;
    }
    
    #workspaces button.urgent {
        background-color: #eb4d4b;
    }
    
    #mode {
        background-color: #64727D;
        box-shadow: inset 0 -3px #ffffff;
    }
    
    #clock,
    #cpu,
    #memory,
    #disk,
    #temperature,
    #pulseaudio,
    #network,
    #tray,
    #custom-song,
    #custom-weather.
    
    #window,
    #workspaces {
        border: 2px inset transparent;
        border-radius: 5px;
        margin: 1 4px;
        background-color: rgba(30, 30, 30, 0.4);
    }
     
        
    /* If workspaces is the leftmost module, omit left margin */
    .modules-left > widget:first-child > #workspaces {
        margin-left: 0;
        border: 1.6px solid $accentcolour;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, 0.6);
    }
    
    /* If workspaces is the rightmost module, omit right margin */
    .modules-right{
        padding: 0 1px;
        border: 1.6px solid $accentcolour;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, .4);
    }
    
    #clock {
        border: 1.6px solid $accentcolour;
        border-radius: 5px;
        background-color: rgba(0, 0, 0, 0.4);
    }


    @keyframes blink {
        to {
            background-color: #ffffff;
            color: #000000;
        }
    }

    /* Using steps() instead of linear as a timing function to limit cpu usage */

    #cpu {
        color: #ffffff;
    }

    #custom-song {
        border-radius: 0px;
        border-right: 1.6px solid $accentcolour;
        padding-right: 10px;
        color: #ffffff;
    }

    #custom-weather {
        margin-top: 5px;
    }

    #memory {
    }

    #pulseaudio {
        color: #ffffff;
    }

    #pulseaudio.muted {
        color: #ffffff;
    }

    #network {
    }

    #tray {
        border: 1.6px solid $accentcolour;
        background-color: rgba(0,0,0,.5);
        border-radius: 5px;
        box-shadow: inset 0 -3px transparent;
    }

    #tray > .passive {
        box-shadow: inset 0 -3px transparent;
        -gtk-icon-effect: dim;
    }

    #tray > .needs-attention {
        -gtk-icon-effect: highlight;
        box-shadow: inset 0 -3px #ffffff;
    }
EOF
elif [ $# -eq 0 ]; then
    echo -e "-h help,\n-s set colour (setcol -s 0,0,0 0,0,0 .5)"
    exit 1
fi


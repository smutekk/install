#/bin/bash

# funy cava

while :
do
  if pgrep -i cava > /dev/null; then
    if hyprctl clients | grep -A 0 "title: cava"; then
      if hyprctl clients | grep -A 0 "floating: 1"; then
        hyprctl dispatch setfloating title:cava
        hyprctl dispatch resizewindowpixel 1920 1080 title:cava
        break
      fi
    fi
    echo 'cava! :D'
  else
    echo 'faggot D:'
  fi
done




ghostty --title=cava -e cava

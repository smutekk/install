
echo fuck

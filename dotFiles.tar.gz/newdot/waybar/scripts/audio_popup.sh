  # Open pavucontrol and make it floating
  pavucontrol &
  sleep 0.2
    hyprctl keyword windowrule "float, title:^Volume Control$"

  hyprctl keyword windowrule "size 400 300, title:^Volume Control$"
  hyprctl keyword windowrule "move 200 200, title:^Volume Control$"
  hyprctl keyword windowrule "float, title:^pavucontrol$"



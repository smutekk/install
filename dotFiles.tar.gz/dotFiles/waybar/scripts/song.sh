#!/bin/bash

touch ~/tmp/song.txt | songrec listen | tee ~/tmp/song.txt

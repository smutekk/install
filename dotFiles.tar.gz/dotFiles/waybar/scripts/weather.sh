#!/bin/bash

touch ~/tmp/weather.txt | wttr -n | sed -n 5p ~/tmp/weather.txt
